<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 230021 - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="w-full max-w-md bg-white rounded-lg shadow-md p-6">
        <h1 class="text-3xl font-bold text-center text-blue-600 mb-4">CATSHOP 230021</h1>
        <h3 class="text-xl text-center text-blue-500 mb-4">LOGIN PAGE</h3>
        <h3 class="text-xl text-center text-blue-500 mb-4">Username : vq</h3>
        <h3 class="text-xl text-center text-blue-500 mb-4">Password : Vik20satr</h3>
        <hr class="mb-4">

        <?php if ($this->session->flashdata('msg')): ?>
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                <?= $this->session->flashdata('msg') ?>
            </div>
        <?php endif; ?>

        <?php if (validation_errors()): ?>
            <div class="bg-red-100 text-red-700 px-4 py-2 rounded mb-4">
                <?= validation_errors() ?>
            </div>
        <?php endif; ?>

        <form action="" method="post" class="space-y-4">
            <div>
                <label class="block font-medium mb-1">Username</label>
                <input type="text" name="username" required class="w-full border border-gray-300 px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block font-medium mb-1">Password</label>
                <input type="password" name="password" required class="w-full border border-gray-300 px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <input type="submit" name="login" value="LOGIN" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 cursor-pointer">
            </div>
        </form>
    </div>

</body>
</html>

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 230021</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans text-gray-800">

    <div class="max-w-lg mx-auto mt-12 p-6 bg-white rounded-lg shadow-md">
        <h1 class="text-3xl font-bold text-blue-600 mb-2">CATSHOP 230021</h1>
        <h3 class="text-xl text-blue-500 mb-4">CHANGE PHOTO</h3>

        <?php if($this->session->flashdata('msg')): ?>
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                <?= $this->session->flashdata('msg') ?>
            </div>
        <?php endif; ?>

        <?php if(!empty($error)): ?>
            <div class="bg-red-100 text-red-700 px-4 py-2 rounded mb-4">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form action="" method="post" enctype="multipart/form-data" class="space-y-6">
            <div>
                <label class="block font-medium mb-1">Current Photo</label>
                <img src="<?= base_url('uploads/users/'.$this->session->userdata('photo')) ?>" width="128" height="128" class="rounded border">
            </div>
            <div>
                <label class="block font-medium mb-1">New Photo</label>
                <input type="file" name="photo" required class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700">
            </div>
            <div>
                <input type="submit" name="upload" value="UPLOAD PHOTO" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 cursor-pointer">
            </div>
        </form>

        <hr class="my-6 border-gray-300">
        <a href="<?= base_url() ?>" class="text-blue-600 hover:underline block text-center">
            ← Back to Home
        </a>
    </div>

</body>
</html>

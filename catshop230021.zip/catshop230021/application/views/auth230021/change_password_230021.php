<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 230021</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans text-gray-800">

    <div class="max-w-lg mx-auto mt-12 p-6 bg-white rounded-lg shadow-md">
        <h1 class="text-3xl font-bold text-blue-600 mb-2">CATSHOP 230021</h1>
        <h3 class="text-xl text-blue-500 mb-4">CHANGE PASSWORD</h3>
        <hr class="border-blue-400 mb-6">

        <?php if($this->session->flashdata('msg')): ?>
            <div class="bg-blue-100 text-blue-800 px-4 py-2 rounded mb-4">
                <?=$this->session->flashdata('msg')?>
            </div>
        <?php endif; ?>

        <?php if(validation_errors()): ?>
            <div class="bg-red-100 text-red-700 px-4 py-2 rounded mb-4">
                <?= validation_errors(); ?>
            </div>
        <?php endif; ?>

        <form action="" method="post" class="space-y-4">
            <div>
                <label class="block text-sm font-medium mb-1">Old Password</label>
                <input type="password" name="oldpassword" required
                    class="w-full p-2 border border-blue-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">New Password</label>
                <input type="password" name="newpassword" required
                    class="w-full p-2 border border-blue-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <input type="submit" value="CHANGE PASSWORD" name="change"
                    class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 cursor-pointer">
            </div>
        </form>

        <hr class="my-6 border-gray-300">
        <a href="<?=base_url()?>" class="text-blue-600 hover:underline block text-center">
            ← Back to Home
        </a>
    </div>

</body>
</html>

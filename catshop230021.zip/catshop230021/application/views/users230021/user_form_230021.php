<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Cats</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans text-gray-800">

    <div class="max-w-2xl mx-auto mt-10 p-6 bg-white shadow-md rounded-lg">
        <h1 class="text-3xl font-bold text-blue-600 mb-2">CATSHOP 230021</h1>
        <h3 class="text-xl text-blue-500 mb-4">USER FORM</h3>
        <hr class="border-blue-400 mb-6">

        <?php if ($this->session->flashdata('msg')): ?>
            <div class="bg-blue-100 text-blue-800 px-4 py-2 rounded mb-4">
                <?= $this->session->flashdata('msg'); ?>
            </div>
        <?php endif; ?>

        <?php 
        $username = $usertype = $fullname = '';

        if (isset($user)) {
            $username = $user->username_230021 ?? '';
            $usertype = $user->usertype_230021 ?? '';
            $fullname = $user->fullname_230021 ?? '';
        }
        ?>

        <form action="" method="post" class="space-y-4">
            <div>
                <label class="block text-sm font-medium mb-1">Username</label>
                <input type="text" name="username_230021" value="<?= $username ?>" required
                    class="w-full p-2 border border-blue-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">Usertype</label>
                <div class="flex gap-4">
                    <label class="flex items-center gap-2">
                        <input type="radio" name="usertype_230021" value="Cashier" <?= ($usertype == "Cashier") ? 'checked' : '' ?>>
                        Cashier
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="radio" name="usertype_230021" value="Manager" <?= ($usertype == "Manager") ? 'checked' : '' ?>>
                        Manager
                    </label>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">Fullname</label>
                <input type="text" name="fullname_230021" value="<?= $fullname ?>" required
                    class="w-full p-2 border border-blue-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="flex items-center space-x-4 pt-2">
                <input type="submit" value="SAVE" name="submit"
                    class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 cursor-pointer">
                <a href="<?= site_url('users230021') ?>">
                    <button type="button"
                        class="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 cursor-pointer">
                        CANCEL
                    </button>
                </a>
            </div>
        </form>
    </div>

</body>
</html>

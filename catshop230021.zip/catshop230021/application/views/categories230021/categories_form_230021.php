<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 230021</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans text-gray-800">

    <div class="max-w-2xl mx-auto mt-10 p-6 bg-white shadow-md rounded-lg">
        <h1 class="text-3xl font-bold text-blue-600 mb-2">CATSHOP 230021</h1>
        <h3 class="text-xl text-blue-500 mb-4">CATEGORIES FORM</h3>
        <hr class="border-blue-400 mb-6">

        <?php
            $name = '';
            $description = '';

            if (isset($categories)) {
                $name = $categories->cate_name_230021;
                $description = $categories->description_230021;
            }
        ?>

        <form action="" method="post">
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Name</label>
                <input type="text" name="cate_name_230021" value="<?= $name ?>" required 
                       class="w-full p-2 border border-blue-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Description</label>
                <textarea name="description_230021" required 
                          class="w-full p-2 border border-blue-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"><?= $description ?></textarea>
            </div>
            <div class="flex items-center space-x-4">
                <input type="submit" value="SAVE" name="submit"
                       class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 cursor-pointer">
                <a href="<?= site_url('categories230021') ?>">
                    <button type="button"
                            class="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 cursor-pointer">
                        CANCEL
                    </button>
                </a>
            </div>
        </form>
    </div>

</body>
</html>

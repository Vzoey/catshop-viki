<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 230021</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light py-4">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 fw-bold text-primary">CATSHOP 230021</h1>
                <h4 class="text-secondary">Categories List</h4>
            </div>
            <a href="<?= base_url() ?>" class="btn btn-outline-secondary">Home</a>
        </div>

        <?php if ($this->session->flashdata('msg')): ?>
            <div class="alert alert-success"><?= $this->session->flashdata('msg') ?></div>
        <?php endif; ?>

        <div class="mb-3">
            <a href="<?= site_url('categories230021/add') ?>" class="btn btn-primary">+ Add New Category</a>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-striped table-bordered mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th colspan="2" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($categories as $category): ?>
                            <tr>
                                <td><?= $i++ ?></td>
                                <td><?= $category->cate_name_230021 ?></td>
                                <td><?= $category->description_230021 ?></td>
                                <td class="text-center">
                                    <a href="<?= site_url('categories230021/edit/' . $category->id_cate_230021) ?>" class="btn btn-sm btn-warning">Edit</a>
                                </td>
                                <td class="text-center">
                                    <a href="<?= site_url('categories230021/delete/' . $category->id_cate_230021) ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure you want to delete this category?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 230021</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            min-height: 100vh;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            flex-shrink: 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar .nav-link.active {
            background-color: #495057;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
        }
        .user-dropdown img {
            width: 50px;  /* Increased size */
            height: 50px; /* Increased size */
            object-fit: cover;
            border-radius: 50%;
        }
        .user-dropdown .user-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3">
        <h4 class="mb-4">CATSHOP 230021</h4>
        <ul class="nav nav-pills flex-column mb-auto">
            <li class="nav-item">
                <a href="<?=site_url('cats230021')?>" class="nav-link">Manage Cats</a>
            </li>
            <li>
                <a href="<?=site_url('categories230021')?>" class="nav-link">Manage Categories</a>
            </li>
            <?php if($this->session->userdata('usertype')=='Manager') { ?>
            <li>
                <a href="<?=site_url('users230021')?>" class="nav-link">Manage Users</a>
            </li>
            <li>
                <a href="<?=site_url('cats230021/sales')?>" class="nav-link">Sales Report</a>
            </li>
            <?php } ?>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content w-100">
        <!-- Top right user dropdown -->
        <div class="d-flex justify-content-end mb-3">
            <div class="dropdown user-dropdown">
                <a class="btn btn-light dropdown-toggle d-flex align-items-center flex-column" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="<?=base_url('uploads/users/'.$this->session->userdata('photo'))?>" alt="User Photo" class="me-2">
                    <div class="user-info">
                        <span><?=$this->session->userdata('fullname')?></span>
                        <small class="text-muted"><?=$this->session->userdata('usertype')?></small>
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="<?=site_url('auth230021/changephoto')?>">Change Photo</a></li>
                    <li><a class="dropdown-item" href="<?=site_url('auth230021/changepass')?>">Change Password</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="<?=site_url('auth230021/login')?>">Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Page Content -->
        <h3>APPS MENU</h3>
        <hr>
        <p>Welcome <strong><?=$this->session->userdata('fullname')?></strong>, you are logged in as <strong><?=$this->session->userdata('usertype')?></strong></p>
    </div>
</body>
</html>

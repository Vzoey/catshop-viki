<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 230021</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light text-dark p-4">
    <div class="container">
        <h1 class="mb-2 fw-bold">CATSHOP 230021</h1>
        <h3 class="mb-4">CATS LIST</h3>
        <a href="<?=base_url()?>" class="text-decoration-underline text-primary mb-3 d-inline-block">HOME</a>
        
        <?php if($this->session->flashdata('msg')): ?>
            <div class="alert alert-success my-2"><?= $this->session->flashdata('msg') ?></div>
        <?php endif; ?>
        
        <a href="<?=site_url('cats230021/add')?>" class="btn btn-primary mb-3">Add New Cat</a>
        
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Gender</th>
                        <th>Age (Month)</th>
                        <th>Price ($)</th>
                        <th colspan="3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; foreach($cats as $cat) { ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= $cat->name_230021 ?></td>
                        <td><?= $cat->type_230021 ?></td>
                        <td><?= $cat->gender_230021 ?></td>
                        <td><?= $cat->age_230021 ?></td>
                        <td><?= $cat->price_230021 ?></td>
                        <td><a href="<?=site_url('cats230021/edit/'.$cat->id_230021)?>" class="btn btn-sm btn-warning">Edit</a></td>
                        <td><a href="<?=site_url('cats230021/delete/'.$cat->id_230021)?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</a></td>
                        <td>
                            <?php if($cat->sold_230021==1): ?>
                                <span class="text-muted">SOLD</span>
                            <?php else: ?>
                                <a href="<?=site_url('cats230021/sale/'.$cat->id_230021)?>" class="btn btn-sm btn-success">Sale</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-4">
            <?= $this->pagination->create_links() ?>
        </div>
    </div>
</body>
</html>

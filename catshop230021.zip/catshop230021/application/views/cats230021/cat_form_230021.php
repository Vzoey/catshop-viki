<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Cats</title>
    <!-- Link CDN Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans text-gray-800">

    <div class="container mx-auto p-6 bg-white shadow-lg rounded-lg mt-10">
        <h1 class="text-3xl font-semibold text-blue-600">CATSHOP 230021</h1>
        <h3 class="text-xl text-blue-500 mb-6">CATS FORM</h3>
        <hr class="border-blue-400 mb-4">

        <!-- Flash message -->
        <?php if ($this->session->flashdata('msg')): ?>
            <div class="mb-4 text-center text-white bg-green-500 py-2 rounded-lg">
                <?= $this->session->flashdata('msg'); ?>
            </div>
        <?php endif; ?>

        <?php 
        $name = $type = $gender = $age = $price = '';

        if (isset($cat)) {
            $name = $cat->name_230021 ?? '';
            $type = $cat->type_230021 ?? '';
            $gender = $cat->gender_230021 ?? '';
            $age = $cat->age_230021 ?? '';
            $price = $cat->price_230021 ?? '';
        }
        ?>

        <form action="<?= site_url('cats230021/' . (isset($cat) ? 'edit/' . $cat->id_230021 : 'add')) ?>" method="post">
            <table class="w-full text-left">
                <tr>
                    <td class="py-2 px-4">Name</td>
                    <td class="py-2 px-4"><input type="text" name="name_230021" value="<?= $name ?>" class="border-2 border-blue-300 p-2 rounded" required></td>
                </tr>
                <tr>
                    <td class="py-2 px-4">Type</td>
                    <td class="py-2 px-4">
                        <select name="type_230021" class="border-2 border-blue-300 p-2 rounded" required>
                            <option value="">Choose type</option>
                            <?php foreach ($category as $cate): ?>
                                <option value="<?= $cate->cate_name_230021 ?>" <?= ($type == $cate->cate_name_230021) ? 'selected' : '' ?>>
                                    <?= $cate->cate_name_230021 ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="py-2 px-4">Gender</td>
                    <td class="py-2 px-4">
                        <input type="radio" name="gender_230021" value="Male" <?= ($gender == "Male") ? 'checked' : '' ?> class="mr-2"> Male
                        <input type="radio" name="gender_230021" value="Female" <?= ($gender == "Female") ? 'checked' : '' ?> class="mr-2"> Female
                    </td>
                </tr>
                <tr>
                    <td class="py-2 px-4">Age (months)</td>
                    <td class="py-2 px-4"><input type="number" name="age_230021" value="<?= $age ?>" class="border-2 border-blue-300 p-2 rounded" required></td>
                </tr>
                <tr>
                    <td class="py-2 px-4">Price ($)</td>
                    <td class="py-2 px-4"><input type="number" name="price_230021" value="<?= $price ?>" class="border-2 border-blue-300 p-2 rounded" required></td>
                </tr>
                <tr>
                    <td class="py-2 px-4"></td>
                    <td class="py-2 px-4">
                        <input type="submit" value="SAVE" name="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 cursor-pointer">
                        <a href="<?= site_url('cats230021') ?>">
                            <input type="button" value="CANCEL" class="bg-gray-300 text-gray-800 px-6 py-2 rounded-lg hover:bg-gray-400 cursor-pointer">
                        </a>
                    </td>
                </tr>
            </table>
        </form>
    </div>

</body>
</html>

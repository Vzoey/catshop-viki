<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Cats</title>
</head>
<body>
    <h1>CATSHOP 230021</h1>
    <h3>CATS FORM</h3>

    <form action="" method="post">
        <table>
            <tr>
                <td>Cat ID</td>
                <td><?=$cat->id_230021?></td>
            </tr>
            <tr>
                <td>Cat Name</td>
                <td><?=$cat->name_230021?></td>
            </tr>
            <tr>
                <td>Cat Type</td>
                <td><?=$cat->type_230021?></td>
            </tr>
            <tr>
                <td>Cat Price</td>
                <td><?=$cat->price_230021?></td>
            </tr>
            </tr>
            <tr>
                <td>Customer Name</td>
                <td><input type="text" name="customer_name_230021"></td>
            </tr>
            </tr>
            <tr>
                <td>Customer Address</td>
                <td><textarea name="customer_address_230021"></textarea></td>
            </tr>
            </tr>
            <tr>
                <td>Customer Phone</td>
                <td><input type="text" name="customer_phone_230021"></td>
            </tr>
            <tr>
                <td>
                    <input type="submit"  value="SALE" name="submit">
                    <a href="<?= site_url('cats230021') ?>"><input type="button" value="CANCEL"></a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
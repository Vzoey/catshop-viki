<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth230021_model extends CI_Model {

    public function getuser($username)
    {
        $this->db->where('username_230021', $username);
        return $this->db->get('users230021')->row();
    }

    public function changepass()
    {
        $this->db->set('password_230021', password_hash($this->input->post('newpassword'), PASSWORD_DEFAULT));
        $this->db->where('username_230021', $this->session->userdata('username'));
        return $this->db->update('users230021');
    }

    public function resetpassword($username, $hashedPassword)
    {
        $this->db->set('password_230021', $hashedPassword);
        $this->db->where('username_230021', $username);
        return $this->db->update('users230021');
    }

    public function changephoto($photo)
  {
    if($this->session->userdata('photo') !== 'default.png')
    unlink('./uploads/users/'.$this->session->userdata('photo'));


    $this->db->set('photo_230021', $photo);
    $this->db->where('username_230021', $this->session->userdata('username'));
    return $this->db->update('users230021');

  }
}

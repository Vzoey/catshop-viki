<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cats230021_model extends CI_Model {

	public function create()
	{
       $data = array(
            'name_230021' => $this->input->post('name_230021'),
            'type_230021' => $this->input->post('type_230021'),
            'gender_230021' => $this->input->post('gender_230021'),
            'age_230021' => $this->input->post('age_230021'),
            'price_230021' => $this->input->post('price_230021')
        );
        $this->db->insert('cats230021', $data);
	}
    
    public function read($limit, $start)
    {
        $this->db->limit($limit, $start);
        $query = $this->db->get('cats230021');
        return $query->result();
    }

    public function read_by($id)
    {
        $this->db->where('id_230021', $id);
        $query = $this->db->get('cats230021');
        return $query->row();
    }

    public function update($id)
    {
        $data = array(
            'name_230021' => $this->input->post('name_230021'),
            'type_230021' => $this->input->post('type_230021'),
            'gender_230021' => $this->input->post('gender_230021'),
            'age_230021' => $this->input->post('age_230021'),
            'price_230021' => $this->input->post('price_230021')
        );
        $this->db->where('id_230021', $id);
        $this->db->update('cats230021', $data);
    }

    public function delete($id)
    {
        $this->db->where('id_230021', $id);
        $this->db->delete('cats230021');
    }

    public function validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('name_230021', 'Cat name', 'required');
        $this->form_validation->set_rules('type_230021', 'Cat type', 'required');
        $this->form_validation->set_rules('gender_230021', 'Cat gender', 'required');
        $this->form_validation->set_rules('age_230021', 'Cat age', 'required|numeric');
        $this->form_validation->set_rules('price_230021', 'Cat price', 'required|numeric');

        return $this->form_validation->run();
    }

    public function sold($id)
    {
        $data = array (
            'customer_name_230021' => $this->input->post('customer_name_230021'),
            'customer_address_230021' => $this->input->post('customer_address_230021'),
            'customer_phone_230021' => $this->input->post('customer_phone_230021'),
            'cat_id_230021' => $id
        ); 
        $this->db->insert('catsales230021', $data);

        $this->db->set('sold_230021', '1');
        $this->db->where('id_230021', $id);
        $this->db->update('cats230021');
    }

    public function sales()
    {
        $query = $this->db->get('catsales230021');
        return $query->result();
    }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users230021_model extends CI_Model {

    public function create ()
    {
        $data = array(
            'username_230021' => $this->input->post('username_230021'),
            'usertype_230021' => $this->input->post('usertype_230021'),
            'fullname_230021' => $this->input->post('fullname_230021'),
            'password_230021' => password_hash($this->input->post('usertype_230021'), PASSWORD_DEFAULT)
        );
        $this->db->insert('users230021', $data);
    }

    public function read()
    {
        $query = $this->db->get('users230021');
        return $query->result();
    }

    public function read_by($userid)
    {
        $this->db->where('userid_230021', $userid);
        $query = $this->db->get('users230021');
        return $query->row();
    }

    public function update($userid)
    {
        $data = array(
            'username_230021' => $this->input->post('username_230021'),
            'usertype_230021' => $this->input->post('usertype_230021'),
            'fullname_230021' => $this->input->post('fullname_230021')
        );
        $this->db->where('userid_230021', $userid);
        return $this->db->update('users230021', $data);
    }
    
    public function delete($userid)
    {
        $this->db->where('userid_230021', $userid);
        return $this->db->delete('users230021');
    }
}

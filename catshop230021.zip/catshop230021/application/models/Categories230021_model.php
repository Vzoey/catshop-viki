<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories230021_model extends CI_Model {

    public function create()
    {
        $data = array(
            'cate_name_230021' => $this->input->post('cate_name_230021'),
            'description_230021' => $this->input->post('description_230021')
        );
        return $this->db->insert('categories230021', $data);
    }

    public function read()
    {
        $query = $this->db->get('categories230021');
        return $query->result();
    }

    public function read_by($id)
    {
        $this->db->where('id_cate_230021', $id);
        $query = $this->db->get('categories230021');
        return $query->row();
    }

    public function update($id)
    {
        $data = array(
            'cate_name_230021' => $this->input->post('cate_name_230021'),
            'description_230021' => $this->input->post('description_230021')
        );
        $this->db->where('id_cate_230021', $id);
        return $this->db->update('categories230021', $data);
    }

    public function delete($id)
    {
        $this->db->where('id_cate_230021', $id);
        return $this->db->delete('categories230021');
    }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users230021 extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if(! $this->session->userdata('username')) redirect('auth230021/login');
        if ($this->session->userdata('usertype') != 'Manager') redirect ('welcome');
        $this->load->model('Users230021_model');
    }

    public function index()
    {
        $data['users'] = $this->Users230021_model->read();
        $this->load->view('users230021/user_list_230021', $data);
    }

    public function add()
    {
        if($this->input->post('submit')) {
            $this->Users230021_model->create();
            if($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('msg','<p style="color:green"> User successfully added !</p>');
            } else {
                $this->session->set_flashdata('msg','<p style="color:red"> User added failed !</p>');
            }
            redirect('users230021');
        }
        $this->load->view('users230021/user_form_230021');
    }

    public function edit($userid)
    {
        if($this->input->post('submit')) {
            $this->Users230021_model->update($userid);
            if($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('msg','<p style="color:green"> User successfully updated !</p>');
            } else {
                $this->session->set_flashdata('msg','<p style="color:red">User updated failed !</p>');
            }
            redirect('Users230021');
        }
        $data['user']=$this->Users230021_model->read_by($userid); 
        $this->load->view('users230021/user_form_230021',$data);     
    }
    
    public function delete($userid)
    {
        $this->Users230021_model->delete($userid);
        if($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('msg','<p style="color:green"> Users successfully deleted !</p>');
        } else {
            $this->session->set_flashdata('msg','<p style="color:red">Users deleted failed !</p>');
        }
        redirect('Users230021');
    }

}
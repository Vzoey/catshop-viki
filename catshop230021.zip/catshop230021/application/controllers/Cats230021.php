<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cats230021 extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if(! $this->session->userdata('username')) redirect('auth230021/login');
        $this->load->model('Cats230021_model');
        $this->load->model('Categories230021_model');
    }

	public function index()
	{
        $this->load->library('pagination');

        $config['base_url'] = site_url('cats230021/index');
        $config['total_rows'] = $this->db->count_all('cats230021');
        $config['per_page'] = 5;

        $this->pagination->initialize($config);

        $limit=$config['per_page'];
        $start=$this->uri->segment(3)?$this->uri->segment(3):0;

        $data['i']=$start+1;
        $data['cats']=$this->Cats230021_model->read($limit, $start);
		$this->load->view('cats230021/cat_list_230021',$data);
	}
    
        public function add()
        {
            if($this->input->post('submit')) {
                $this->Cats230021_model->create();
                if($this->db->affected_rows() > 0) {
                    $this->session->set_flashdata('msg','<p style="color:green"> Cat successfully added !</p>');
                } else {
                    $this->session->set_flashdata('msg','<p style="color:red">Cat added failed !</p>');
                }
                redirect('cats230021');
            }
            $data['category']=$this->Categories230021_model->read();
            $this->load->view('cats230021/cat_form_230021', $data);
        }   

    public function edit($id)
    {
        if($this->input->post('submit')) {
            $this->Cats230021_model->update($id);
            if($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('msg','<p style="color:green"> Cat successfully updated !</p>');
            } else {
                $this->session->set_flashdata('msg','<p style="color:red">Cat updated failed !</p>');
            }
            redirect('cats230021');
        }
        $data['category']=$this->Categories230021_model->read();
        $data['cat']=$this->Cats230021_model->read_by($id);   
        $this->load->view('cats230021/cat_form_230021',$data);     
    }
    
    public function delete($id)
    {
        $this->Cats230021_model->delete($id);
        if($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('msg','<p style="color:green"> Cat successfully deleted !</p>');
        } else {
            $this->session->set_flashdata('msg','<p style="color:red">Cat deleted failed !</p>');
        }
        redirect('cats230021');
    }

    public function sale($id)
    {
        if($this->input->post('submit')){
            $this->Cats230021_model->sold($id);  
            if($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('msg','<p style="color:green"> Cat successfully sold !</p>');
            } else {
                $this->session->set_flashdata('msg','<p style="color:red">Cat sale failed !</p>');
            }
            redirect('cats230021');
        }
        $data['cat']=$this->Cats230021_model->read_by($id);   
        $this->load->view('cats230021/cat_sale_230021',$data);     
    }

    public function sales()
    {
        if ($this->session->userdata('usertype') != 'Manager') redirect ('welcome');
        $data['sales']=$this->Cats230021_model->sales();   
        $this->load->view('cats230021/sale_list_230021',$data);
    }
}